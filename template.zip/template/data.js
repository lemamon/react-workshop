exports.data = [
    {
        sites: "Google",
        views: "9518",
        clicks: "6369",
        average: "01:32:50"
    },
    {
        sites: "Twitter",
        views: "7326",
        clicks: "10437",
        average: "00:51:22"
    },
    {
        sites: "Amazon",
        views: "4162",
        clicks: "5327",
        average: "00:24:34"
    },
    {
        sites: "LinkedIn",
        views: "3654",
        clicks: "2961",
        average: "00:12:10"
    },
    {
        sites: "CodePen",
        views: "2002",
        clicks: "4135",
        average: "00:46:19"
    },
    {
        sites: "GitHub",
        views: "4623",
        clicks: "3486",
        average: "00:31:52"
    },
];